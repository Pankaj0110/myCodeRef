

export default function(state = {todos:['Taking bath','Enjoying morning prayers']}, action){
    switch(action.type){
        case 'ADD_TODO':{
            state = {...state, todos: state.todos.concat(action.payload)};
            break;
        }
        case 'GET_TODOS':{
            state = {...state, todos:action.payload};
            break;
        }
        case 'REMOVE_TODO':{
            state = {...state, todos: state.todos.filter((todo,index)=> index!=action.payload)}
        }
    }
    return state;
}