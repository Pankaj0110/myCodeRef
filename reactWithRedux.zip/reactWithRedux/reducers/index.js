import { combineReducers } from '../node_modules/redux';

import  todos  from './todo-reducer';

export default combineReducers({
    todos,
}) 