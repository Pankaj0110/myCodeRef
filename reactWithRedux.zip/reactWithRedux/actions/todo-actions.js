import Axios from "../node_modules/axios";


export function addTodo(todo){
    return{
        type:'ADD_TODO',
        payload: todo
    }
}

export function getTodos(){
    return function(dispatch){
        Axios.get("https://jsonplaceholder.typicode.com/todos")
        .then((response)=> {
            dispatch({
                type:'GET_TODOS',
                payload:response.data
            })
        })
        .catch((err)=> console.log('error->> ', e))
    }
}


export function removeTodo(index){
    return {
        type:'REMOVE_TODO',
        payload:index
    }
}