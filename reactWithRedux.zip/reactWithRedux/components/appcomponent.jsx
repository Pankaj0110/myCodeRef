import React from 'react';
import {ReactDom} from 'react-dom';
import * as todoActions from '../actions/todo-actions';

import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';

@connect((store)=>{
    console.log(store);
    return {
        todos: store.todos.todos
    }
} ,
(dispatch) => {
    return {
        actions: bindActionCreators(todoActions, dispatch)
    }
})
export class AppComponent extends React.Component {
    render(){
        console.log(this.props)
        return(
            <div>
            <h1 style={{textAlign:'center', color: '#aaa', fontFamily:' Segoe UI'}}>React With Redux</h1>         
            {this.props.todos.map((todo, index)=>{
               return <li>{todo} <span onClick={this.removetodo.bind(this, index)}>X</span></li>
            })}
            <button onClick={this.addtodo.bind(this)}>Add New Todo </button>
            </div>
        )
    }

    componentDidMount(){
        //this.props.dispatch(todoActions.getTodos());
    }

    addtodo(){
       // this.dispatch(todoActions.addTodo('take a nap'))
       this.props.actions.addTodo('take a nap');
       //this.props.dispatch(todoActions.addTodo('ppp'))
    }

    removetodo(index){
        this.props.actions.removeTodo(index)
    }
}

export default AppComponent;