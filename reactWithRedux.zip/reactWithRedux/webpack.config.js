const config = {
    mode:'development',
    entry:'./main.js',
    output:{
        path:'/',
        filename:'index.js'
    },

    devServer:{
        inline:true,
        port: 7777
    },

    module:{
        rules:[
            {
                test:/\.jsx?$/,
                exclude:'/node_modules/',
                loader:'babel-loader',
                query:{
                    presets:['es2015','react',"stage-0"],
                    plugins:['transform-decorators-legacy']
                }
            }
        ]
    }
}

module.exports = config;