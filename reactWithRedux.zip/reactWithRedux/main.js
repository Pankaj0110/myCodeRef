import React from 'react';
import ReactDom from 'react-dom';
import { Provider } from 'react-redux';

import AppComponent from './components/appcomponent.jsx';
import store from './app-store';

ReactDom.render(<Provider store={store}><AppComponent/></Provider>, document.getElementById('wrapper'));