

import React from 'react';

class Signup extends React.Component{

    constuctor(){
        this.save = this.save.bind(this);
        this.formdata ={};
    }
    render(){
        return(
            <div className="container single-form-container">
                <div className="row">
                    <div className="col-sm-2 col-sm-offset-5">
                            <h4 className="title-text center">Register</h4>
                    </div>
                </div>
           
            <form className="form-horizontal">
                    <div className="form-group">
                        <label className="col-sm-3 control-label">User Name</label>
                        <div className="col-sm-8">
                            <input ref="username" id="name" className="form-control"  type="text" placeholder="enter username"/>
                        </div>
                    </div>
                    <div className="form-group">
                        <label className="col-sm-3 control-label">Email</label>
                        <div className="col-sm-8">
                            <input ref="email" id="mail" className="form-control" type="email" placeholder="enter email id"/>
                        </div>
                    </div>
                    <div className="form-group">
                        <label className="col-sm-3 control-label">Phone Number</label>
                        <div className="col-sm-8">
                            <input ref="phonenumber" id="number" className="form-control" type="tel" placeholder="enter phone number"/>
                        </div>
                    </div>
                    <div className="form-group">
                        <label className="col-sm-3 control-label">Password</label>
                        <div className="col-sm-8">
                            <input ref="password" id="pwd" className="form-control" type="password" placeholder="enter password for account"/>
                        </div>
                    </div>  
                    <div className="form-group">
                        <label className="col-sm-3 control-label">Confirm Password</label>
                        <div className="col-sm-8">
                            <input ref="confirmpassword" id="cpwd" className="form-control"  type="password" placeholder="confirm password"/>
                        </div>
                    </div>
    
                    <div className="form-group">
                        <div className="col-sm-2 col-sm-offset-5">
                                <button className="form-control btn btn-primary center" type="button" onClick={this.save}>Register</button> 
                        </div>
                    </div>
            </form>
        </div>)
    }

    componentDidUpdate(){
        console.log('update on signup page-> ', this.props)
        console.log(this.props.dispatcher)
    }

    componentDidUpdate(){
        console.log(this.refs.username)
          this.formdata = {
            
            username: this.refs.username.value,
            email: this.refs.email.value,
        }
    }

    save(){
       // console.log(this.refs.username);
       // let data = {}
       /* let data = {
            username : this.refs.username,
            emailid : this.refs.emailid,
            phonenumber : this.refs.phonenumber,
            password : this.refs.password
        } */

        
       // this.dispatcher.signup(data);
       console.log(Signup.formdata);

    }
}

export default Signup;