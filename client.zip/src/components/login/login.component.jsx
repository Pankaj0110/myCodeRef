

import React from 'react';

class Login extends React.Component{
    render(){
        return (
            <div class="container single-form-container">
            <div class="row">
                <div class="col-sm-2 col-sm-offset-5">
                        <h4 class="title-text center">Login</h4>
                </div>
            </div>
       
        <form class="form-horizontal">
                <div class="form-group">
                    <label class="col-sm-3 control-label">User Name</label>
                    <div class="col-sm-8">
                        <input class="form-control" id="focusedInput" type="text" placeholder="enter username"/>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-sm-3 control-label">Password</label>
                    <div class="col-sm-8">
                        <input class="form-control" id="focusedInput" type="password" placeholder="password"/>
                    </div>
                </div>
                <div class="form-group">
                    <div class="col-sm-2 col-sm-offset-5">
                            <button class="form-control btn btn-primary center" type="submit">Login</button> 
                    </div>
                </div>
        </form>        
        </div>
        )
    }
}

export default Login;