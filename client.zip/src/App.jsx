import React, { Component } from 'react';
import Signup from './components/signup/signup.component.jsx';
import Login from './components/login/login.component.jsx';
import {Switch, Route, Link, withRouter } from 'react-router-dom';
//import logo from '../public/img/Shoping-Bag-PNG.png';
import logo from './logo.svg'
import './App.css';

import * as productActions from './actions/product.actions';

import { connect } from 'react-redux';
import { bindActionCreator, bindActionCreators } from 'redux';
import Products from './components/products/product.component';



/* @connect((store)=>{
  console.log("product-store :: ",store);
  return {
    products: store.products
  }
},
(dispatch)=>{
  return {
    actions: bindActionCreators(productActions, dispatch)
  }
}) */
// I am using alternative for this. since as of now unable to user @annotations
export class App extends Component {
  render() {
    return (
      <div>  
      <div className="App">
        <header className="App-header">
          <img src={logo} className="App-logo" alt="logo" />
       {/*    <h1 className="App-title">Welcome to React</h1> */}
          <nav>
            <ul>
              <li><Link to='/'>Home</Link></li>
              <li><Link to='/signup'>Sign up</Link></li>
              <li><Link to='/login'>Login</Link></li>
            </ul>
          </nav>
        </header>
        
      </div>
      <Switch>
        <Route exact path='/'  render={(props) => (<Products products={this.props.products.products} {...props}/>)}/>
        <Route path='/signup'render={(props) => (<Signup dispatcher={this.props.actions} {...props}/>)}/>
        <Route path="/login" component={Login}/>
      </Switch>
     {/*  <Products products={this.props.products.products}/>
    
     */}
      </div>   
    );
  }

  componentDidMount(){
    this.props.actions.getProducts();
  }
}













function mapStatetoProps(store){
  console.log("product-store :: ",store);
  return {
    products: store.products
  }
}
 function mapDispatchToProps(dispatch){
  return {
    actions: bindActionCreators(productActions, dispatch)
  }
}

export default withRouter(connect(mapStatetoProps, mapDispatchToProps)(App));
