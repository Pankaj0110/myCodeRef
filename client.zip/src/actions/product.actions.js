
import Axios from 'axios';

export function getProducts(){

    return function(dispatch){
        Axios.get('/products')
        .then((response)=>{
            dispatch({
                type:'GET_PRODUCTS',
                payload: response.data
            })
        })
        .catch((err)=> console.log("error::", err));
    }
}


export function signup(data){
    return{
        type:'SIGNUP',
        payload:data
    }
}