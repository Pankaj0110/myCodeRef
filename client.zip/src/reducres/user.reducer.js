import Axios from 'axios';

export default function(state = {}, action){
    switch(action.type){
        case 'SIGNUP':{
            Axios.post('/signup',action.payload)
            .then(res => res.json())
            .then(user =>{
                state = {...state, user:action.payload }
                console.log('state in user --> ', state)
            })
            break;
        }
    }

    return state;
}