import { combineReducers } from 'redux';

import products from './product.reducer';
import users from './user.reducer';

export default combineReducers({
    products,
    users
})