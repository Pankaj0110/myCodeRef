

export default function(state = {products:[]}, action){
    switch(action.type){
        case 'GET_PRODUCTS':{
            state = {...state, products:action.payload }
            break;
        }
    }

    return state;
}